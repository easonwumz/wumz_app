require('luabin')
luabin.path = playerconf.DUICORE_HOME .. '/hybrid.lub;' .. playerconf.DATA_HOME .. '/core.lub'

local processor = require 'player.node.processor'
processor:run()

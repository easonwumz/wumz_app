require('luabin')
local lubs = {
    playerconf.DATA_HOME .. '/core.lub',
    playerconf.DUICORE_HOME .. '/hybrid.lub',
    playerconf.DUICORE_HOME .. '/res/nlu/semantic1.lub'
}

luabin.path = table.concat(lubs, ';')

local cpathbak = package.cpath
package.cpath = string.gsub(cpathbak, '/%?.so', '/?1.so') .. ';' .. cpathbak

print('-------player.node.builtin_skill----------')
local bsnode = require 'player.node.builtin_skill'
bsnode:run()

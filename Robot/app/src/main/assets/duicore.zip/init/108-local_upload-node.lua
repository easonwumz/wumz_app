require('luabin')
luabin.path = playerconf.DUICORE_HOME .. '/hybrid.lub;' .. playerconf.DATA_HOME .. '/core.lub;' .. playerconf.DUICORE_HOME .. '/corelib.lub'

package.path = package.path ..';'.. playerconf.DUICORE_HOME .. '/res/?/init.lua;'

local upload = require 'player.node.upload'
upload:run()